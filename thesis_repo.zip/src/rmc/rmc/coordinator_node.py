import os, time, math, socket, threading, csv
import serial
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Int32

def now_mono(): return time.monotonic()

def parse_gcode_positions(path):
    pos = []; cur = {'X':0.0,'Y':0.0,'Z':0.0}; abs_mode=True
    with open(path,'r') as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith(';'): continue
            if s.startswith('G90'): abs_mode=True;  continue
            if s.startswith('G91'): abs_mode=False; continue
            if s.startswith(('G0','G1')):
                nx=ny=nz=None
                for p in s.split()[1:]:
                    c=p[0].upper()
                    if c in 'XYZ':
                        try: v=float(p[1:])
                        except: continue
                        if c=='X': nx=v
                        if c=='Y': ny=v
                        if c=='Z': nz=v
                if abs_mode:
                    if nx is not None: cur['X']=nx
                    if ny is not None: cur['Y']=ny
                    if nz is not None: cur['Z']=nz
                else:
                    if nx is not None: cur['X']+=nx
                    if ny is not None: cur['Y']+=ny
                    if nz is not None: cur['Z']+=nz
                pos.append((cur['X'],cur['Y'],cur['Z']))
    return pos

def is_ok(s): return s.strip().lower().startswith("ok") and "resend" not in s.lower()

def drain(ser, buf):
    n = ser.in_waiting; lines=[]
    if n:
        buf += ser.read(n)
        parts = buf.split(b'\n'); buf = parts[-1]
        for p in parts[:-1]:
            try: t = p.decode(errors='ignore').strip()
            except: t = ""
            if t: lines.append(t)
    return buf, lines

def send_line(ser, line): ser.write((line.strip()+"\r\n").encode())

class Coordinator(Node):
    def __init__(self):
        super().__init__('rebel_marlin_coordinator')

        p = self.declare_parameter
        self.gcode_file    = p('gcode_file', 'square_plate.gcode').value
        self.serial_port   = p('serial_port', '/dev/ttyACM0').value
        self.baud          = p('baud', 115200).value
        self.robot_ip      = p('robot_ip', '192.168.3.11').value
        self.robot_port    = p('robot_port', 3920).value
        self.offset_x      = float(p('offset_x', 350.0).value)
        self.offset_y      = float(p('offset_y',   0.0).value)
        self.offset_z      = float(p('offset_z', 220.0).value)
        self.speed         = float(p('speed', 30.0).value)
        self.dt            = float(p('dt', 0.02).value)
        self.nmin          = int(p('nmin', 8).value)
        self.nmax          = int(p('nmax',12).value)
        self.coast_sec     = float(p('coast_sec', 0.04).value)
        self.robot_min_gap = float(p('robot_min_gap', 0.06).value)
        self.retry_limit   = int(p('retry_limit', 5).value)
        self.fan_pwm       = int(p('fan_pwm', 255).value)
        self.log_csv       = p('log_csv', 'ros2_run_log.csv').value
        self.w             = float(p('line_w', 0.48).value)
        self.h             = float(p('layer_h',0.20).value)
        self.Af            = math.pi * (1.75/2)**2
        self.flow_mult     = float(p('flow_mult', 1.0).value)
        self.windowed      = bool(self.declare_parameter('windowed', True).value)
        

        if not os.path.exists(self.gcode_file):
            raise FileNotFoundError(f"G-code not found: {self.gcode_file}")
        self.positions = parse_gcode_positions(self.gcode_file)
        if len(self.positions) < 2:
            raise RuntimeError("No motion segments parsed.")
        self.seg_times = []
        geom_len = 0.0
        prev = self.positions[0]
        for pnt in self.positions[1:]:
            L = math.hypot(pnt[0]-prev[0], pnt[1]-prev[1])
            t = L / max(1e-6, self.speed)
            if self.coast_sec>0: t = max(0.0, t - self.coast_sec)
            self.seg_times.append(t); geom_len += L; prev = pnt

        bead_area = self.w * self.h
        E_rate = (bead_area * self.speed) / self.Af
        E_rate *= self.flow_mult
        self.dE = E_rate * self.dt
        self.F  = E_rate * 60.0
        self.ticks_total = max(1, int(round(sum(self.seg_times)/self.dt)))
        self.get_logger().info(
            f"Path={geom_len:.1f} mm | segs={len(self.seg_times)} | ΔE={self.dE:.5f} | F={self.F:.1f} | ticks≈{self.ticks_total}"
        )

        self.ser = serial.Serial(self.serial_port, self.baud, timeout=0, write_timeout=1)
        time.sleep(2.0); self.ser.reset_input_buffer()
        self.buf = b""
        self._send_preamble()
        
       
        self.csvf = open(self.log_csv, 'w', newline='')
        self.csvw = csv.writer(self.csvf)
        self.csvw.writerow(["t_send","sid_send","t_ok","sid_ok","inflight_after_send","inflight_after_ok"]); self.csvf.flush()

        self.buf = b""; self.inflight = 0; self.sent_ticks = 0; self.sid = 0
        self.sock = self._connect_robot()
        self._send_robot("CRISTART 2000 CMD MotionTypeCartBase CRIEND")

        self.extr_timer = self.create_timer(self.dt, self._extruder_cb)
        self.fan_timer  = self.create_timer(3.0, lambda: send_line(self.ser, f"M106 S{self.fan_pwm}"))

        self.robot_thread = threading.Thread(target=self._robot_loop, daemon=True)
        self.robot_thread.start()
        self.hb_pub = self.create_publisher(String, 'coordinator/heartbeat', 10)
        self.if_pub = self.create_publisher(Int32,  'coordinator/inflight',  10)
        self.hb_timer = self.create_timer(1.0, lambda: self.hb_pub.publish(String(data='alive')))
        def _hb_tick():
                self.hb_pub.publish(String(data='alive'))
        
        self.hb_timer = self.create_timer(1.0, _hb_tick)


    def _send_preamble(self):
        seq = ["M302 S220","M104 S235","M109 S235","M83","G92 E0","M155 S0"]
        for line in seq:
            send_line(self.ser, line)
            t0 = now_mono()
            while True:
                self.buf, ls = drain(self.ser, self.buf)
                if any(is_ok(x) for x in ls): break
                if now_mono() - t0 > 180: raise RuntimeError(f"Timeout waiting ok after: {line}")
                time.sleep(0.01)
        send_line(self.ser, f"M106 S{self.fan_pwm}")  # heatsink fan ON

    def _connect_robot(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        s.settimeout(5.0)
        s.connect((self.robot_ip, self.robot_port))
        self.get_logger().info(f"Connected to ReBeL at {self.robot_ip}:{self.robot_port}")
        return s

    def _recv_robot(self):
        try:
            data = self.sock.recv(4096).decode("utf-8", errors="ignore")
            if data and "ERROR" in data:
                self.get_logger().error(f"ROBOT ERROR: {data.strip()}"); return False
            return True
        except socket.timeout:
            return True

    def _send_robot(self, cmd):
        try:
            self.sock.sendall((cmd + "\r\n").encode("utf-8"))
            return self._recv_robot()
        except Exception as e:
            self.get_logger().warn(f"Robot socket issue: {e}")
            return False

    def _extruder_cb(self):
    # ---- Drain 'ok' acknowledgments ----
        self.buf, ls = drain(self.ser, self.buf)
        for s in ls:
            if is_ok(s) and self.inflight > 0:
                self.inflight -= 1
                # publish current occupancy for rqt_graph / debugging
                self.if_pub.publish(Int32(data=self.inflight))

        # ---- Finished? stop timer and cool down ----
        if self.sent_ticks >= self.ticks_total:
            self.destroy_timer(self.extr_timer)
            send_line(self.ser, "G1 E-0.8 F1800")
            send_line(self.ser, "M104 S0")
            return

        # ---- Admission policy ----
        if not self.windowed:
            # NAÏVE: always admit one line per timer tick
            send_line(self.ser, f"G1 E{self.dE:.5f} F{self.F:.1f}")
            self.inflight += 1
            self.sent_ticks += 1
            self.sid += 1
            self.if_pub.publish(Int32(data=self.inflight))
            return

        # WINDOWED: keep occupancy within [nmin, nmax]
        if self.inflight <= self.nmin:
            while self.inflight < self.nmax and self.sent_ticks < self.ticks_total:
                send_line(self.ser, f"G1 E{self.dE:.5f} F{self.F:.1f}")
                self.inflight += 1
                self.sent_ticks += 1
                self.sid += 1
                self.if_pub.publish(Int32(data=self.inflight))
        elif self.inflight < self.nmax:
            send_line(self.ser, f"G1 E{self.dE:.5f} F{self.F:.1f}")
            self.inflight += 1
            self.sent_ticks += 1
            self.sid += 1
            self.if_pub.publish(Int32(data=self.inflight))
    def _robot_loop(self):
        last_send = now_mono()
        tries = 0
        for (x, y, z), seg_t in zip(self.positions[1:], self.seg_times):
            xr, yr, zr = x + self.offset_x, y + self.offset_y, z + self.offset_z
            cmd = f"CRISTART 2000 CMD Move Cart {xr:.2f} {yr:.2f} {zr:.2f} 0 180 0 0 0 0 {self.speed:.1f} CRIEND"

            ok = self._send_robot(cmd)
            while not ok and tries <  self.retry_limit:
                tries += 1
                try: self.sock.close()
                except: pass
                time.sleep(0.3)
                self.sock = self._connect_robot()
                ok = self._send_robot(cmd)
            tries = 0

            gap = max(0.95*seg_t, self.robot_min_gap)
            sleep_for = (last_send + gap) - now_mono()
            if sleep_for > 0: time.sleep(sleep_for)
            last_send = now_mono()

        self.get_logger().info("Motion complete; cooling down.")
        for _ in range(60):
            send_line(self.ser, f"M106 S{self.fan_pwm}")
            time.sleep(1.0)
        send_line(self.ser, "M106 S0")
        self.csvf.flush(); self.csvf.close()
        self.get_logger().info("Job complete & cooled.")

def main():
    rclpy.init()
    node = Coordinator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try: node.sock.close()
        except: pass
        try: node.ser.close()
        except: pass
        node.destroy_node()
        rclpy.shutdown()
